docker build -t node-server .
docker run -it --rm node-server