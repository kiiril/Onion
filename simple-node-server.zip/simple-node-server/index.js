const express = require('express');
const app = express();
const port = 8080;

const os = require('os');

function getHostIp() {
    const networkInterfaces = os.networkInterfaces();
    let ipAddress = '';

    for (const interfaceName in networkInterfaces) {
        for (const iface of networkInterfaces[interfaceName]) {
            if (iface.family === 'IPv4' && !iface.internal) {
                ipAddress = iface.address;
                break;
            }
        }
        if (ipAddress) {
            break;
        }
    }

    return ipAddress || 'IP address not found';
}

// Endpoint to return the sender's IP address and an HTML page
app.get('/get-ip', (req, res) => {
    const ip = req.ip;

    // Print the IP address to the console
    console.log(`Request received from IP: ${ip}`);

    // Send a simple HTML page as a response
    const htmlContent = `
        <!DOCTYPE html>
        <html lang="en">
        <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>IP Address</title>
        </head>
        <body>
            <h1>Your IP address is: ${ip}</h1>
        </body>
        </html>
    `;
    res.send(htmlContent);
});

// Start the server
app.listen(port, () => {
    console.log(`Server's URL: http://${getHostIp()}:${port}/get-ip`);
});

